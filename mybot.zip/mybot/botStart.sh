#!/bin/bash

node bot.js